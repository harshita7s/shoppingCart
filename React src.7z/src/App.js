import React, { Component } from 'react';
import './App.css';
import Projects from './Components/projects'

class App extends Component {
  constructor() {
    super();
    this.state = {
      projects: [
        {
          title: 'Business Website',
          category: 'Web Design',
          projectManager: 'Shri Ram',
          details: [{
            id: 1,
            duration: '10 days',
            budget: '2 lakh'
          },
          {
            id: 2,
            duration: '100 days',
            budget: '20 lakh'
          }
          ]
        },
        {
          title: 'Socia App',
          category: 'App Development',
          projectManager: 'Shruti Dev',
          details: [{
            id: 3,
            duration: '20 days',
            budget: '4 lakh'
          },
          {
            id: 4,
            duration: '200 days',
            budget: '40 lakh'
          }
          ]
        },
        {
          title: 'Shopping Cart',
          category: 'Web Development',
          projectManager: 'Sonali Singh',
          details: [{
            id: 5,
            duration: '30 days',
            budget: '6 lakh'
          },
          {
            id: 6,
            duration: '300 days',
            budget: '60 lakh'
          }
          ]
        }
      ]
    };
  }

  render() {
    return (
      <div className="App">
        <h1>My React App</h1>
        <Projects projects={this.state.projects} />
      </div>
    );
  }
}

export default App;
