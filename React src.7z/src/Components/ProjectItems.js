import React, { Component } from 'react';
import ProjectItemsDetails from './ProjectItemsDetails'

class ProjectItems extends Component {
  render() {
    let projectItemsDetails;
      if(this.props.projects.details){
          projectItemsDetails=this.props.projects.details.map(projectDetails=>
          {//console.log(projectDetails);
            return(
            <ProjectItemsDetails key={projectDetails.id} projectDetails={projectDetails}/>
          );
          }
        );
          
      }
    return (
      <tr>
        <td>{this.props.projects.title}</td>
        <td>{this.props.projects.category}</td>
        <td>{this.props.projects.projectManager}</td>
        {projectItemsDetails}
      </tr>
    );
  }
}

export default ProjectItems;
