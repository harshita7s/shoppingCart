import React, { Component } from 'react';


class ProjectItemsDetails extends Component {
  render() {
    return (
        <tr>
        <td>{this.props.projectDetails.duration}</td>
        <td>{this.props.projectDetails.budget}</td>
        </tr>
    );
  }
}

export default ProjectItemsDetails;
