import React, { Component } from 'react';
import ProjectItems from './ProjectItems'

class Projects extends Component {
  render() {
      let projectItems;
      if(this.props.projects){
          projectItems=this.props.projects.map(project=>
          {//console.log(project);
            return(
            <ProjectItems key={project.title} projects={project}/>
          );
          }
        );
          
      }
    return (
      <div className="pro">
        My Projects Component 
        <table align="center" border="1">
          <tr>
            <th>Title</th>
            <th>Category</th>
            <th>Manager</th>
            <th>Details<th>Duration</th>
                <th>Budg.</th></th>
          </tr>
          {projectItems}</table>
      </div>
    );
  }
}

export default Projects;
