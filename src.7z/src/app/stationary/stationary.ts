export class Stationary {
  id: number;
  product: string;
  price:number;
  discount:string;
  imageUrl:string;
}