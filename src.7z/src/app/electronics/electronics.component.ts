import { Component, OnInit } from '@angular/core';
import {IElectronic} from './electronics';
import {ProductService} from '../product.service'

@Component({
  selector: 'app-electronics',
  templateUrl: './electronics.component.html',
  styleUrls: ['./electronics.component.css']
})
export class ElectronicsComponent implements OnInit {
pageTitle="Electronics List";
Electronics:IElectronic[];
imageWidth:number=200;
imageHeight:number=150;
cartProductsId:number[];
constructor(private productService:ProductService) { }

getElectronics():void{
  this.Electronics=this.productService.getElectronics();
}
  ngOnInit() {
    this.getElectronics();
    this.cartProductsId=this.productService.getCartProductsId();
  }
addToCart(proid,proName,proPrice,proImage){
  sessionStorage.setItem('id',proid);
  sessionStorage.setItem('product',proName);
  sessionStorage.setItem('price',proPrice);
  sessionStorage.setItem('image',proImage);
  this.productService.addProduct();
  this.cartProductsId=this.productService.getCartProductsId();
}
removeFromCart(proid){
  this.productService.removeProduct(proid);
  this.cartProductsId=this.productService.getCartProductsId();
}
}
