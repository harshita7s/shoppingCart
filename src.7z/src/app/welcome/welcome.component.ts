import { Component, OnInit } from '@angular/core';
import {ProductComponent} from '../product/product.component';
import { Router } from '@angular/router';


@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  title ='CapG Shopping Cart'

  constructor(private route:Router) { }

  ngOnInit() {

  }

loadProducts():void
{
  this.route.navigate(['/product']);
}
}
